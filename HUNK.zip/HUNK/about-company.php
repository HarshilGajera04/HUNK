<?php include ('header.php') ?>
<!-- start page title -->
<section class="top-space-margin page-title-big-typography cover-background magic-cursor round-cursor"
    style="background-image: url(images/HUNK/about2.jpg)">
    <div class="container">
        <div class="row extra-very-small-screen align-items-center">
            <div class="col-lg-5 col-sm-8 position-relative page-title-extra-small"
                data-anime='{ "el": "childs", "opacity": [0, 1], "translateX": [-30, 0], "duration": 800, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <h1 class="mb-20px text-white text-shadow-medium"><span
                        class="w-30px h-2px bg-yellow d-inline-block align-middle position-relative top-minus-2px me-10px"></span>Our
                    company</h1>
                <h2 class="text-white text-shadow-medium fw-500 ls-minus-2px mb-0">About Hunk Ventures </h2>
            </div>
        </div>
    </div>
</section>
<!-- end page title -->
<!-- start section -->
<section>
    <div class="container">
        <div class="row justify-content-center mb-3">
            <div class="col-lg-7 col-md-8 col-sm-9 text-center"
                data-anime='{ "translateY": [50, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
                <h3 class="text-dark-gray fw-700 ls-minus-2px">Why choose us as your premier
                    provider ?</h3>
            </div>
        </div>
        <div class="row row-cols-0 row-cols-lg-1 row-cols-md-2 justify-content-center mb-5"
            data-anime='{ "el": "childs", "translateX": [-30, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
            <!-- start features box item -->
            <div class="col icon-with-text-style-07 transition-inner-all md-mb-30px">
                <div class="bg-very-light-gray h-100 justify-content-end feature-box  p-5 md-p-15 border-radius-8px">
                    <div class="feature-box-icon">
                        <!-- <a href="services.html"><img src="images/HUNK/component1.png" class="h-95px"
                                    alt=""></a> -->
                    </div>
                    <div class="feature-box-content">
                        <p class="mb-10px" style="font-size: 20px;"> Hunk Ventures was established in 2022 with the
                            vision of becoming a
                            premier
                            provider of technical personnel, drivers, logistic support, and network testing
                            services.
                            we embarked on our journey with a commitment to excellence, quality, and customer
                            satisfaction. This is the story of our growth, challenges, and achievements.</p>
                        <br>
                        <p class="mb-10px" style="font-size: 20px;">
                            A group of industry veterans who recognized a growing need for specialized
                            service providers in the rapidly evolving business landscape. The founders, each with
                            extensive experience in their respective fields, envisioned a company that could offer
                            comprehensive soluƟons across multiple sectors. The idea was to create a one-stop
                            solution for businesses seeking reliable technical support, skilled drivers, efficient
                            logistic
                            operations, and robust network tesƟng services
                        </p>
                        <br>

                        <p class="mb-10px" style="font-size: 20px;">Our technical personnel services became
                            particularly popular among
                            enterprises
                            that needed expert support without the overhead of full-time employees. The logistics
                            and drivers' services also saw significant uptake, especially among local businesses
                            looking for reliable transportation solutions. Network testing services, although a
                            niche
                            offering, attracted tech-savvy clients who understood the importance of maintaining a
                            robust IT infrastructure</p>
                    </div>
                </div>
            </div>
            <!-- end features box item -->
        </div>
         
    </div>
</section>
<!-- end section -->
        <!-- start section -->
        <section class="border-bottom border-color-extra-medium-gray mt-0 pt-0">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-xl-5 col-lg-6 md-mb-9 sm-mb-50px" data-anime='{ "el": "childs", "translateY": [50, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 100, "easing": "easeOutQuad" }'>
                        <span class="fs-17 d-inline-block fw-500 text-uppercase text-base-color ls-1px mb-15px">About company</span>
                        <h1 class="alt-font fw-600 text-dark-gray ls-minus-2px mb-35px shadow-none" data-shadow-animation="true" data-animation-delay="700">At Hunk <span class="text-highlight">Ventures<span class="bg-base-color h-10px sm-h-8px bottom-20px md-bottom-17px opacity-5 separator-animation"></span></span> </h1>
                        <div class="row">
                            <div class="col-lg-12 col-md-6 mb-25px last-paragraph-no-margin">
                                <!-- <span class="fw-500 text-dark-gray fs-20 mb-5px d-inline-block">Company benefits</span> -->
                                <p class="w-85 md-w-95 sm-w-100">A group of industry veterans who recognized a growing need for specialized service providers in the rapidly evolving business landscape.</p>
                            </div>
                           
                        </div>
                        <a href="services.php" class="btn btn-large btn-dark-gray btn-box-shadow fw-400 btn-round-edge mt-10px md-mt-0">Our services</a>
                    </div>
                    <div class="col-xl-6 offset-xl-1 col-lg-6 position-relative md-mb-6 sm-mb-50px">
                        <div class="overflow-hidden text-end w-80 ms-auto animation-float" data-anime='{ "effect": "slide", "direction": "lr", "color": "#4daaa7", "duration": 1000, "delay": 0 }'>
                            <img src="images/HUNK/training.jpg" alt="" style="height: 500px; object-fit: cover;" class="w-100 border-radius-5px">
                        </div>
                        <!-- <div class="position-absolute bottom-minus-50px w-60 atropos" data-atropos data-bottom-top="transform: translateY(50px)" data-top-bottom="transform: translateY(-50px)" data-anime='{ "effect": "slide", "direction": "lr", "color": "#4daaa7", "duration": 1000, "delay": 500 }'>
                            <div class="atropos-scale">
                                <div class="atropos-rotate">
                                    <div class="atropos-inner text-center">
                                        <img class="w-100 border-radius-5px" data-atropos-offset="3" src="https://via.placeholder.com/450x367" alt="">
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                </div>
                
            </div>
        </section>
        <!-- end section -->

<?php include ('footer.php') ?>