<!doctype html>
<html class="no-js" lang="en">

<head>
    <title>Hunk Ventures</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="author" content="ThemeZaa">
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <meta name="description"
        content="Elevate your online presence with Crafto - a modern, versatile, multipurpose Bootstrap 5 responsive HTML5, SCSS template using highly creative 48+ ready demos.">
    <!-- favicon icon -->
    <!-- <link rel="shortcut icon" href="images/favicon.png"> -->
    <!-- <link rel="apple-touch-icon" href="images/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png"> -->
    <!-- google fonts preconnect -->
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- style sheets and font icons  -->
    <link rel="stylesheet" href="css/vendors.min.css" />
    <link rel="stylesheet" href="css/icon.min.css" />
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/responsive.css" />
    <link rel="stylesheet" href="demos/accounting/accounting.css" />
</head>

<body data-mobile-nav-style="classic" class="custom-cursor">
    <!-- start cursor -->
    <div class="cursor-page-inner">
        <div class="circle-cursor circle-cursor-inner"></div>
        <div class="circle-cursor circle-cursor-outer"></div>
    </div>
    <!-- end cursor -->
    <!-- start header -->
    <header class="header-with-topbar">
        <!-- start header top bar -->
        <div class="header-top-bar top-bar-dark bg-very-light-gray">
            <div class="container-fluid">
                <div class="row h-45px xs-h-auto align-items-center m-0 xs-pt-5px xs-pb-5px">
                    <div class="col-lg-6 col-md-7 text-center text-md-start xs-px-0">
                        <div class="fs-15 text-dark-gray fw-500">Our technical experts waiting for you! <a
                                href="contact.php" class="text-dark-gray text-decoration-line-bottom fw-600">Contact
                                now</a></div>
                    </div>
                    <div class="col-lg-6 col-md-5 text-end d-none d-md-flex">
                        <div class="widget fs-15 fw-500 me-35px lg-me-25px md-me-0 text-dark-gray"><a
                                href="tel:02228899900"><i class="feather icon-feather-phone-call"></i>+1
                                213-400-5863</a></div>
                        <div class="widget fs-15 fw-500 text-dark-gray d-none d-lg-inline-block"><i
                                class="feather icon-feather-map-pin"></i>110 Ketterer Ct,
                            Lawrence Township, NJ 08648 (USA)</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end header top bar -->
        <!-- start navigation -->
        <nav class="navbar navbar-expand-lg header-light bg-white responsive-sticky">
            <div class="container">
                <div class="col-auto col-lg-2 me-lg-0 me-auto">
                    <a class="navbar-brand" href="index.php">
                        <img src="images/logo.png"
                            data-at2x="images/demo-accounting-logo-black@2x.png" alt="" class="default-logo">
                        <img src="images/logo.png"
                            data-at2x="images/demo-accounting-logo-black@2x.png" alt="" class="alt-logo">
                        <img src="images/demo-accounting-logo-black.png"
                            data-at2x="images/demo-accounting-logo-black@2x.png" alt="" class="mobile-logo">
                    </a>
                </div>
                <div class="col-auto menu-order position-static">
                    <button class="navbar-toggler float-start" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarNav" aria-controls="navbarNav" aria-label="Toggle navigation">
                        <span class="navbar-toggler-line"></span>
                        <span class="navbar-toggler-line"></span>
                        <span class="navbar-toggler-line"></span>
                        <span class="navbar-toggler-line"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav fw-600">
                            <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                            <li class="nav-item"><a href="about-company.php" class="nav-link">Company</a></li>
                            <li class="nav-item dropdown dropdown-with-icon-style02">
                                <a href="services.php" class="nav-link">Services</a>
                                <i class="fa-solid fa-angle-down dropdown-toggle" id="navbarDropdownMenuLink"
                                    role="button" data-bs-toggle="dropdown" aria-expanded="false"></i>
                                <!-- <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <li><a href="demo-accounting-services-details.php"><img
                                                src="images/HUNK/component.png" style="margin: 10px;" alt="">Technical
                                            Personnel</a></li>
                                    <li><a href="demo-accounting-services-details.php"><img
                                                src="images/HUNK/delivery-truck.png" style="margin: 10px;"
                                                alt="">Drivers</a></li>
                                    <li><a href="demo-accounting-services-details.php"><img
                                                src="images/HUNK/forklift.png" style="margin: 10px;" alt="">Logistic
                                            Support</a></li>
                                    <li><a href="demo-accounting-services-details.php"><img
                                                src="images/HUNK/testing.png" style="margin: 10px;" alt="">Network
                                            Testing Services</a></li>
                                </ul> -->
                            </li>
                            <!-- <li class="nav-item"><a href="demo-accounting-process.php" class="nav-link">Process</a></li> -->
                            <!-- <li class="nav-item"><a href="demo-accounting-news.php" class="nav-link">News</a></li>  -->
                            <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-auto col-lg-2 text-end d-none d-sm-flex">
                    <div class="header-icon">
                        <div class="header-button">
                            <a href="contact.php" class="btn btn-small btn-rounded btn-base-color btn-box-shadow">Let's
                                discuss</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
        <!-- end navigation -->
    </header>
    <!-- end header -->