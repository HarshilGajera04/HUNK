<?php include ('header.php') ?>

<!-- start banner -->
<section class="top-space-margin p-0 full-screen md-h-600px sm-h-500px section-dark"
    data-parallax-background-ratio="0.8" style="background-image:url('images/HUNK/backgrond-image.jpg') ">
    <!--1920 x 1100-->
    <div class="container h-100">
        <div class="row align-items-center h-100">
            <div class="col-xl-7 col-md-9 col-sm-9 position-relative text-white"
                data-anime='{ "el": "childs", "opacity": [0, 1], "translateY": [30, 0], "staggervalue": 200, "easing": "easeInOutSine" }'>
                <div class="fs-80 lh-75 sm-fs-65 fw-600 mb-20px text-shadow-large ls-minus-2px">Hunk Ventures.</div>
                <!-- expand business values  -->
                <div>
                    <span class="opacity-5 fs-20 w-70 md-w-85 mb-25px fw-300 d-inline-block">The vision of becoming
                        a premier
                        provider of technical personnel, drivers, logistic support, and network testing
                        services.</span>
                </div>
                <div class="icon-with-text-style-08">
                    <div class="feature-box feature-box-left-icon-middle">
                        <div
                            class="feature-box-icon feature-box-icon-rounded w-65px h-65px rounded-circle bg-yellow me-15px rounded-box">
                            <i class="feather icon-feather-arrow-right text-dark-gray icon-extra-medium"></i>
                        </div>
                        <div class="feature-box-content">
                            <a href="services.php"
                                class="d-inline-block fs-19 text-white text-shadow-double-large">Explore
                                services</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end banner -->

<!-- start section -->
<section class="pt-0">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-lg-6 col-md-11 md-mb-60px sm-mb-40px">
                <div class="row mt-10 align-items-center">
                    <div class="col-xl-5 col-lg-6 col-sm-5 xs-mb-25px text-center">
                        <div class="position-relative">
                            <span class="w-200px h-200px bg-yellow rounded-circle d-inline-block"
                                data-anime='{ "opacity": [0, 1], "staggervalue": 0, "easing": "easeOutQuad" }'></span>
                            <span
                                class="fs-160 lg-fs-150 text-dark-gray fw-700 position-absolute left-0px w-100 top-50 ls-minus-5px md-top-40px"
                                data-anime='{ "opacity": [0, 1], "staggervalue": 200, "easing": "easeOutQuad" }'>2</span>
                        </div>
                    </div>
                    <div class="col-xl-7 col-lg-6 col-sm-7 ps-45px lg-ps-15px last-paragraph-no-margin text-center text-sm-start"
                        data-anime='{  "opacity": [0,1], "delay": 100, "staggervalue": 250, "easing": "easeOutQuad" }'>
                        <h5 class="fw-600 text-dark-gray ls-minus-1px mb-15px">Years working experience.</h5>
                        <p>We put a strong focus on the needs of business to figure out solutions that best fits
                            your demand.</p>
                        <a href="about-company.php"
                            class="btn btn-link btn-hover-animation-switch btn-extra-large text-base-color text-transform-none fw-600 mt-15px">
                            <span>
                                <span class="btn-text">Discover now</span>
                                <span class="btn-icon"><i class="feather icon-feather-arrow-right"></i></span>
                                <span class="btn-icon"><i class="feather icon-feather-arrow-right"></i></span>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 offset-lg-1 col-md-11 contact-form-style-01 position-relative">
                <div class="position-absolute left-minus-25px md-left-minus-5px xs-left-0 top-100px md-top-0px">
                    <img src="images/demo-accounting-home-left-img.jpg" class="w-40px" alt="">
                </div>
                <div class="ps-14 pe-14 pt-12 pb-12 lg-p-12 bg-white box-shadow-quadruple-large border-radius-6px">
                    <h6 class="d-inline-block fw-600 text-dark-gray ls-minus-1px mb-35px sm-mb-25px"
                        data-anime='{ "translateY": [15, 0], "translateX": [-15, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                        Request a free advice?</h6>
                    <!-- start contact form -->
                    <form action="email-templates/contact-form.php" method="post"
                        data-anime='{ "el": "childs", "translateY": [15, 0], "translateX": [-15, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                        <div class="position-relative form-group mb-15px">
                            <span class="form-icon"><i class="bi bi-emoji-smile"></i></span>
                            <input type="text" name="name" class="form-control required" placeholder="Your name*" />
                        </div>
                        <div class="position-relative form-group mb-15px">
                            <span class="form-icon"><i class="bi bi-envelope"></i></span>
                            <input type="email" name="email" class="form-control required"
                                placeholder="Your email address*" />
                        </div>
                        <div class="position-relative form-group mb-20px">
                            <span class="form-icon"><i class="bi bi-telephone-outbound"></i></span>
                            <input type="tel" name="phone" class="form-control" placeholder="Your phone" />
                        </div>
                        <div class="position-relative terms-condition-box text-start d-inline-block">
                            <label>
                                <input type="checkbox" name="terms_condition" id="terms_condition" value="1"
                                    class="terms-condition check-box align-middle required">
                                <span class="box fs-16">I agree to the terms of service.</span>
                            </label>
                        </div>
                        <div class="position-relative mt-20px">
                            <button class="btn btn-large btn-round-edge btn-base-color btn-box-shadow submit w-100"
                                type="submit">Get free quote</button>
                            <div class="form-results mt-20px text-center lh-24 d-none"></div>
                        </div>
                    </form>
                    <!-- end contact form -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end section -->


<!-- start section -->
<section class="bg-gradient-very-light-gray ps-7 pe-7 xxl-ps-3 xxl-pe-3 xs-px-0">
    <div class="container-fluid">
        <div class="row justify-content-center mb-3">
            <div class="col-xl-5 col-lg-7 col-md-8 text-center"
                data-anime='{ "opacity": [0,1], "duration": 800, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <span class="fw-600 ls-1px fs-16 alt-font d-inline-block text-uppercase mb-5px text-base-color">We
                    embarked on our journey with a commitment to
                    excellence, quality, and customer
                    satsfacton.</span>
                <h2 class="alt-font text-dark-gray fw-600 ls-minus-2px">Why choose us as your premier
                    provider?</h2>
            </div>
        </div>
        <div class="row row-cols-1 row-cols-xl-4 row-cols-md-2 row-cols-sm-2 justify-content-center"
            data-anime='{ "el": "childs", "translateX": [30, 0], "opacity": [0,1], "duration": 800, "delay": 200, "staggervalue": 300, "easing": "easeOutQuad" }'>
            <!-- start interactive banner item -->
            <div class="col interactive-banner-style-05 lg-mb-30px position-relative z-index-1">
                <div class="atropos" data-atropos data-atropos-perspective="1450">
                    <a href="#"
                        class="position-absolute z-index-1 top-0px left-0px h-100 w-100"></a>
                    <div class="atropos-scale">
                        <div class="atropos-rotate">
                            <div class="atropos-inner">
                                <figure class="m-0 hover-box border-radius-4px overflow-hidden position-relative"
                                    data-atropos-offset="3">
                                    <img class="w-100 " src="images/HUNK/technical1.jpg" alt=""
                                        style="object-fit: cover; height: 425px;" />
                                    <figcaption
                                        class="d-flex flex-column align-items-start justify-content-center position-absolute left-0px top-0px w-100 h-100 z-index-1 p-15 xl-p-12 last-paragraph-no-margin">
                                        <div
                                            class="mb-auto bg-base-color fw-500 text-white text-uppercase border-radius-30px ps-20px pe-20px fs-13">
                                            Technical
                                            Personnel </div>
                                        <span
                                            class="alt-font text-white fw-500 fs-26 sm-lh-26 xs-lh-28 sm-mb-5px">Technical
                                            Personnel</span>
                                        <p class="text-white opacity-6 fs-18">Skilled professionals for your project's
                                            success</p>
                                        <div
                                            class="position-absolute left-0px top-0px w-100 h-100 bg-gradient-gray-light-dark-transparent z-index-minus-1 opacity-9">
                                        </div>
                                        <div
                                            class="box-overlay bg-gradient-gray-light-dark-transparent z-index-minus-1">
                                        </div>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end interactive banner item -->
            <!-- start interactive banner item -->
            <div class="col interactive-banner-style-05 lg-mb-30px position-relative z-index-1">
                <div class="atropos" data-atropos data-atropos-perspective="1450">
                    <a href="#"
                        class="position-absolute z-index-1 top-0px left-0px h-100 w-100"></a>
                    <div class="atropos-scale">
                        <div class="atropos-rotate">
                            <div class="atropos-inner">
                                <figure class="m-0 hover-box border-radius-4px overflow-hidden position-relative"
                                    data-atropos-offset="3">
                                    <img class="w-100" src="images/HUNK/driver.jpg" alt=""
                                        style="object-fit: cover; height: 425px;" />
                                    <figcaption
                                        class="d-flex flex-column align-items-start justify-content-center position-absolute left-0px top-0px w-100 h-100 z-index-1 p-15 xl-p-12 last-paragraph-no-margin">
                                        <div
                                            class="mb-auto bg-base-color fw-500 text-white text-uppercase border-radius-30px ps-20px pe-20px fs-13">
                                            Drivers</div>
                                        <span class="alt-font text-white fw-500 fs-26 sm-lh-26 xs-lh-28">   Drivers</span>
                                        <p class="text-white opacity-6 fs-18">
                                            Reliable and professional transportation for all.</p>
                                        <div
                                            class="position-absolute left-0px top-0px w-100 h-100 bg-gradient-gray-light-dark-transparent z-index-minus-1 opacity-9">
                                        </div>
                                        <div
                                            class="box-overlay bg-gradient-gray-light-dark-transparent z-index-minus-1">
                                        </div>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end interactive banner item -->
            <!-- start interactive banner item -->
            <div class="col interactive-banner-style-05 sm-mb-30px position-relative z-index-1">
                <div class="atropos" data-atropos data-atropos-perspective="1450">
                    <a href="#"
                        class="position-absolute z-index-1 top-0px left-0px h-100 w-100"></a>
                    <div class="atropos-scale">
                        <div class="atropos-rotate">
                            <div class="atropos-inner">
                                <figure class="m-0 hover-box border-radius-4px overflow-hidden position-relative"
                                    data-atropos-offset="3">
                                    <img class="w-100" src="images/HUNK/logistic.jpg" alt=""
                                        style="object-fit: cover; height: 425px;" />
                                    <figcaption
                                        class="d-flex flex-column align-items-start justify-content-center position-absolute left-0px top-0px w-100 h-100 z-index-1 p-15 xl-p-12 last-paragraph-no-margin">
                                        <div class="mb-auto bg-base-color fw-500 text-white text-uppercase border-radius-30px ps-20px pe-20px fs-13">Logistic Support</div>
                                        <span class="alt-font text-white fw-500 fs-26 sm-lh-26 xs-lh-28">Logistic Support</span>
                                        <p class="text-white opacity-6 fs-18">Streamlined logistics solutions to optimize efficiency.</p>
                                        <div
                                            class="position-absolute left-0px top-0px w-100 h-100 bg-gradient-gray-light-dark-transparent z-index-minus-1 opacity-9">
                                        </div>
                                        <div
                                            class="box-overlay bg-gradient-gray-light-dark-transparent z-index-minus-1">
                                        </div>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end interactive banner item -->
            <!-- start interactive banner item -->
            <div class="col interactive-banner-style-05 position-relative z-index-1">
                <div class="atropos" data-atropos data-atropos-perspective="1450">
                    <a href="#"
                        class="position-absolute z-index-1 top-0px left-0px h-100 w-100"></a>
                    <div class="atropos-scale">
                        <div class="atropos-rotate">
                            <div class="atropos-inner">
                                <figure class="m-0 hover-box border-radius-4px overflow-hidden position-relative"
                                    data-atropos-offset="3">
                                    <img class="w-100" src="images/HUNK/network.jpg" alt=""
                                        style="object-fit: cover; height: 425px;" />
                                    <figcaption
                                        class="d-flex flex-column align-items-start justify-content-center position-absolute left-0px top-0px w-100 h-100 z-index-1 p-15 xl-p-12 last-paragraph-no-margin">
                                        <div class="mb-auto bg-base-color fw-500 text-white text-uppercase border-radius-30px ps-20px pe-20px fs-13">Network Testing Services</div>
                                        <span class="alt-font text-white fw-500 fs-26 sm-lh-26 xs-lh-28">Network Testing Services</span>
                                        <p class="text-white opacity-6 fs-18">Ensuring optimal IT network performance and security.</p>
                                        <div
                                            class="position-absolute left-0px top-0px w-100 h-100 bg-gradient-gray-light-dark-transparent z-index-minus-1 opacity-9">
                                        </div>
                                        <div
                                            class="box-overlay bg-gradient-gray-light-dark-transparent z-index-minus-1">
                                        </div>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end interactive banner item -->
        </div>
    </div>
</section>
<!-- end section -->
       <!-- start section -->
       <section class="half-section pt-0 pb-4 ">
            <div class="container-fluid">
                <div class="row position-relative">
                    <div class="col swiper swiper-width-auto text-center pb-20px md-pb-20px" data-slider-options='{ "slidesPerView": "auto", "spaceBetween":40, "speed": 8000, "loop": true, "allowTouchMove": false, "autoplay": { "delay":0, "disableOnInteraction": false }, "keyboard": { "enabled": true, "onlyInViewport": true }, "effect": "slide" }'>
                        <div class="swiper-wrapper marquee-slide">
                            <!-- start client item -->
                            <div class="swiper-slide">
                                <div class="fs-140 lg-fs-130 md-fs-110 sm-fs-90 text-dark-gray fw-600 ls-minus-6px alt-font">Technical Personnel.</div>
                            </div>
                            <!-- end client item -->
                            <!-- start client item -->
                            <div class="swiper-slide">
                                <div class="fs-140 lg-fs-130 md-fs-110 sm-fs-90 fw-600 text-outline text-outline-color-extra-medium-gray ls-minus-6px alt-font">Drivers.</div>
                            </div>
                            <!-- end client item -->
                            <!-- start client item -->
                            <div class="swiper-slide">
                                <div class="fs-140 lg-fs-130 md-fs-110 sm-fs-90 text-dark-gray fw-600 ls-minus-6px alt-font">Logistic Support.</div>
                            </div>
                            <!-- end client item --> 
                            <!-- start client item -->
                            <div class="swiper-slide">
                                <div class="fs-140 lg-fs-130 md-fs-110 sm-fs-90 fw-600 text-outline text-outline-color-extra-medium-gray ls-minus-6px alt-font">Network Testing Services.</div>
                            </div>
                            <!-- end client item --> 
                            <!-- start client item -->
                            <div class="swiper-slide">
                                <div class="fs-140 lg-fs-130 md-fs-110 sm-fs-90 text-dark-gray fw-600 ls-minus-6px alt-font">Technical Personnel..</div>
                            </div>
                            <!-- end client item -->
                            <!-- start client item -->
                            <div class="swiper-slide">
                                <div class="fs-140 lg-fs-130 md-fs-110 sm-fs-90 fw-600 text-outline text-outline-color-extra-medium-gray ls-minus-6px alt-font"> Drivers.</div>
                            </div>
                            <!-- end client item --> 
                        </div> 
                    </div>  
                </div>
            </div>
        </section>
        <!-- end section -->
<!-- start section -->
<section class="bg-very-light-gray pb-0" id="services">
    <div class="container">
        <div class="row mb-8 sm-mb-10">
            <div class="col-12 tab-style-08">
                <div class="tab-content">
                    <!-- start tab content -->
                    <div class="row justify-content-center mb-6">
                        <div class="col-xl-8 col-md-8 col-sm-10 text-center"
                            data-anime='{ "el": "childs", "translateY": [50, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
                            <h2 class="mb-0 text-dark-gray fw-700 ls-minus-1px w-85 xl-w-100 mx-auto">Additional
                                Opportunities</h2>
                        </div>
                    </div>
                    <div class="tab-pane fade in active show" id="tab_eight1">
                        <div class="row align-items-center justify-content-center g-lg-0">
                            <div class="col-md-6 sm-mb-30px position-relative overflow-hidden"
                                data-anime='{ "effect": "slide", "color": "#4daaa7", "direction":"lr", "easing": "easeOutQuad", "delay":50}'>
                                <img src="images/HUNK/Consulting Services.jpg" style="height: 500px;" alt=""
                                    class="w-100 border-radius-6px">
                                <div class="bg-very-light-gray w-250px position-absolute pt-20px pb-20px ps-25px pe-25px border-radius-4px bottom-30px left-35px box-shadow-large d-flex align-items-center"
                                    data-anime='{ "translateY": [0, 0], "opacity": [0,1], "duration": 1200, "delay": 800, "staggervalue": 500, "easing": "easeOutQuad" }'>
                                    <h2 class="vertical-counter d-inline-flex text-dark-gray fw-700 ls-minus-2px md-ls-minus-1px mb-0 text-nowrap border-end border-1 border-color-transparent-dark-very-light pe-20px me-20px"
                                        data-to="25"></h2>
                                    <span class="text-dark-gray ls-minus-05px d-inline-block lh-22">Project
                                        completed</span>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-5 offset-lg-1 col-md-6 text-center text-md-start"
                                data-anime='{ "el": "childs", "translateX": [50, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
                                <div class="mb-20px">
                                    <div
                                        class="separator-line-1px w-50px bg-base-color d-inline-block align-middle me-10px opacity-2">
                                    </div>
                                    <span
                                        class="d-inline-block text-dark-gray align-middle fw-500 fs-20 ls-minus-05px">Consulting
                                        Services</span>
                                </div>
                                <h4 class="fw-700 text-dark-gray ls-minus-1px md-mb-20px">Consulting Services</h4>
                                <p class="mb-35px md-mb-25px">We offer consulting services to
                                    help businesses optimize their
                                    operations, enhance productivity, and
                                    implement effective strategies for
                                    growth.</p>
                                <a href="services.php"
                                    class="btn btn-large btn-rounded with-rounded btn-white btn-box-shadow fw-600">Learn
                                    more<span class="bg-base-color text-white"><i
                                            class="bi bi-arrow-right-short icon-extra-medium"></i></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- end tab content -->
                    <!-- start tab content -->
                    <div class="tab-pane fade in" id="tab_eight2">
                        <div class="row align-items-center justify-content-center g-lg-0">
                            <div class="col-md-6 sm-mb-30px position-relative overflow-hidden">
                                <img src="images/HUNK/project_management.jpg" style="height: 500px;" alt=""
                                    class="w-100 border-radius-4px">
                                <div
                                    class="bg-very-light-gray w-250px position-absolute pt-20px pb-20px ps-25px pe-25px border-radius-4px bottom-30px left-35px box-shadow-large d-flex align-items-center">
                                    <h2 class="vertical-counter d-inline-flex text-dark-gray fw-700 ls-minus-2px md-ls-minus-1px mb-0 text-nowrap border-end border-1 border-color-transparent-dark-very-light pe-20px me-20px"
                                        data-to="15"></h2>
                                    <span class="text-dark-gray ls-minus-05px d-inline-block lh-22">Project
                                        completed</span>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-5 offset-lg-1 col-md-6 text-center text-md-start">
                                <div class="mb-20px">
                                    <div
                                        class="separator-line-1px w-50px bg-base-color d-inline-block align-middle me-10px opacity-2">
                                    </div>
                                    <span
                                        class="d-inline-block text-dark-gray align-middle fw-500 fs-20 ls-minus-05px">Project
                                        Management</span>
                                </div>
                                <h4 class="fw-700 text-dark-gray ls-minus-1px md-mb-20px">Project Management</h4>
                                <p class="mb-35px md-mb-25px">Our experienced project
                                    managers provide comprehensive
                                    project management services,
                                    ensuring projects are completed on
                                    time, within budget, and to the
                                    highest quality standards.</p>
                                <a href="services.php"
                                    class="btn btn-large btn-rounded with-rounded btn-white btn-box-shadow fw-600">Learn
                                    more<span class="bg-base-color text-white"><i
                                            class="bi bi-arrow-right-short icon-extra-medium"></i></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- end tab content -->
                    <!-- start tab content -->
                    <div class="tab-pane fade in" id="tab_eight3">
                        <div class="row align-items-center justify-content-center g-lg-0">
                            <div class="col-md-6 sm-mb-30px position-relative overflow-hidden">
                                <img src="images/HUNK/training.jpg" style="height: 500px;" alt=""
                                    class="w-100 border-radius-4px">
                                <div
                                    class="bg-very-light-gray w-250px position-absolute pt-20px pb-20px ps-25px pe-25px border-radius-4px bottom-30px left-35px box-shadow-large d-flex align-items-center">
                                    <h2 class="vertical-counter d-inline-flex text-dark-gray fw-700 ls-minus-2px md-ls-minus-1px mb-0 text-nowrap border-end border-1 border-color-transparent-dark-very-light pe-20px me-20px"
                                        data-to="10"></h2>
                                    <span class="text-dark-gray ls-minus-05px d-inline-block lh-22">Project
                                        completed</span>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-5 offset-lg-1 col-md-6 text-center text-md-start">
                                <div class="mb-20px">
                                    <div
                                        class="separator-line-1px w-50px bg-base-color d-inline-block align-middle me-10px opacity-2">
                                    </div>
                                    <span
                                        class="d-inline-block text-dark-gray align-middle fw-500 fs-20 ls-minus-05px">Training
                                        and Development</span>
                                </div>
                                <h4 class="fw-700 text-dark-gray ls-minus-1px md-mb-20px">Training and Development
                                </h4>
                                <p class="mb-35px md-mb-25px">We offer training programs to
                                    upskill your workforce in various
                                    technical and operational areas,
                                    ensuring they are equipped with the
                                    latest knowledge and skills. </p>
                                <a href="#"
                                    class="btn btn-large btn-rounded with-rounded btn-white btn-box-shadow fw-600">Learn
                                    more<span class="bg-base-color text-white"><i
                                            class="bi bi-arrow-right-short icon-extra-medium"></i></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- end tab content -->

                </div>
            </div>
        </div>
    </div>
    <div class="tab-style-08 border-bottom border-color-extra-medium-gray bg-white box-shadow-quadruple-large">
        <div class="container">
            <!-- start tab navigation -->
            <ul class="nav nav-tabs border-0 fw-500 fs-19 text-center">
                <li class="nav-item"><a data-bs-toggle="tab" href="#tab_eight1" class="nav-link active">Consulting
                        Services<span class="tab-border bg-base-color"></span></a></li>
                <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab_eight2"
                        data-tab="counter">Project Management<span class="tab-border bg-base-color"></span></a></li>
                <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab_eight3"
                        data-tab="counter">Training and Development<span class="tab-border bg-base-color"></span></a>
                </li>
                <!-- <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab_eight4" data-tab="counter">Business planning<span class="tab-border bg-base-color"></span></a></li> -->
            </ul>
            <!-- end tab navigation -->
        </div>
    </div>
</section>
<!-- end section -->
<?php include ('footer.php') ?>