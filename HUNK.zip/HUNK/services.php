<?php include ('header.php') ?>

<!-- start page title -->
<section class="top-space-margin page-title-big-typography cover-background magic-cursor round-cursor"
    style="background-image: url(images/HUNK/services.jpg)">
    <div class="container">
        <div class="row extra-very-small-screen align-items-center">
            <div class="col-lg-5 col-sm-8 position-relative page-title-extra-small"
                data-anime='{ "el": "childs", "opacity": [0, 1], "translateX": [-30, 0], "duration": 800, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <h1 class="mb-20px xs-mb-20px text-white text-shadow-medium"><span
                        class="w-30px h-2px bg-yellow d-inline-block align-middle position-relative top-minus-2px me-10px"></span>Popular
                    services</h1>
                <h2 class="text-white text-shadow-medium fw-500 ls-minus-2px mb-0">Professional services</h2>
            </div>
        </div>
    </div>
</section>
<!-- end page title -->

<!-- start section -->
<section class="bg-very-light-gray">
    <div class="container">
        <div class="row justify-content-center mb-3">
            <!-- <div class="row justify-content-center mb-6"> -->
            <div class="col-xl-6 col-md-8 col-sm-10 text-center"
                data-anime='{ "el": "childs", "translateY": [50, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
                <h4 class="mb-0 text-dark-gray fw-700 ls-minus-1px w-85 xl-w-100 mx-auto">Serviecs</h4>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row row-cols-1 row-cols-lg-2 row-cols-md-2 justify-content-center"
            data-anime='{ "el": "childs", "translateY": [50, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
            <!-- start features box item -->
            <div class="col icon-with-text-style-07 transition-inner-all mb-30px">
                <div
                    class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                    <div class="feature-box-icon">
                        <a href="services.html"><img src="images/HUNK/component1.png" style="margin-top: 20px;"
                                class="h-95px" alt=""></a>
                    </div>
                    <div class="feature-box-content">
                        <a href="services.html"
                            class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Technical
                            Personnel</a>
                        <p class="mb-30px">At Hunk Ventures, we provide highly skilled technical professionals
                            proficient in various
                            fields, including IT, engineering, software development, and more. Our experts are available
                            to support your projects and operational requirements, ensuring you have the right talent
                            for every challenge..</p>
                    </div>
                </div>
            </div>
            <!-- end features box item -->
            <!-- start features box item -->
            <div class="col icon-with-text-style-07 transition-inner-all mb-30px">
                <div
                    class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                    <div class="feature-box-icon">
                        <a href="demo-accounting-services-details.html"><img src="images/HUNK/delivery-truck1.png"
                                style="margin-top: 50px;" class="h-95px" alt=""></a>
                    </div>
                    <div class="feature-box-content">
                        <a href="services.html"
                            class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Drivers</a>
                        <p class="mb-30px">Our team of reliable and experienced drivers is ready to meet your
                            transportation needs.
                            We offer services for corporate transportation, personal travel, and logistical operaƟons,
                            all
                            conducted with the highest standards of professionalism and safety.</p>
                    </div>
                    <!-- <span
                            class="position-absolute box-shadow-large top-25px lg-top-15px right-25px lg-right-15px bg-base-color border-radius-18px text-white fs-11 fw-600 text-uppercase ps-15px pe-15px lh-26 ls-minus-05px">New</span> -->
                </div>
            </div>
            <!-- end features box item -->
            <!-- start features box item -->
            <div class="col icon-with-text-style-07 transition-inner-all mb-30px">
                <div
                    class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                    <div class="feature-box-icon">
                        <a href="demo-accounting-services-details.html"><img src="images/HUNK/forklift1.png"
                                style="margin-top: -20px;" class="h-95px" alt=""></a>
                    </div>
                    <div class="feature-box-content">
                        <a href="services.html"
                            class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Logistic Support</a>
                        <p class="mb-30px">We provide end-to-end logistic solutions to streamline your business
                            processes. Our
                            services include supply chain management, inventory management, order fulfillment,
                            transportation coordination, and warehouse operaƟons. We tailor our soluƟons to enhance
                            efficiency and reduce operational costs.</p>
                    </div>
                </div>
            </div>
            <!-- end features box item -->
            <!-- start features box item -->
            <div class="col icon-with-text-style-07 transition-inner-all mb-30px">
                <div
                    class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                    <div class="feature-box-icon">
                        <a href="demo-accounting-services-details.html"><img src="images/HUNK/testing1.png"
                                style="margin-top: -20px;" class="h-95px" alt=""></a>
                    </div>
                    <div class="feature-box-content">
                        <a href="services.html"
                            class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Network Testing
                            Services</a>
                        <p class="mb-30px">Our expert team conducts thorough network tesƟng to ensure the optimal
                            performance and reliability of your IT infrastructure. We specialize in network diagnosƟcs,
                            performance evaluation, security testing, and maintenance, helping you maintain a robust and
                            secure network environment.</p>
                    </div>
                </div>
            </div>
            <!-- end features box item -->
            <!-- start features box item -->
            <!-- <div class="col icon-with-text-style-07 transition-inner-all md-mb-30px">
                <div
                    class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                    <div class="feature-box-icon">
                        <a href="demo-accounting-services-details.html"><img src="images/HUNK/testing1.png"
                                class="h-95px" alt=""></a>
                    </div>
                    <div class="feature-box-content">
                        <a href="demo-accounting-services-details.html"
                            class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Network Testing
                            Services</a>
                        <p class="mb-30px">Our expert team conducts thorough network tesƟng to ensure the optimal
                            performance
                            and reliability of your IT infrastructure. We specialize in network diagnosƟcs, performance
                            evaluation, security testing, and maintenance, helping you maintain a robust and secure
                            network environment.</p>
                    </div>
                </div>
            </div> -->
            <!-- end features box item -->
            <!-- start features box item -->
            <!-- <div class="col icon-with-text-style-07 transition-inner-all sm-mb-30px">
                    <div
                        class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                        <div class="feature-box-icon">
                            <a href="demo-accounting-services-details.html"><img
                                    src="images/demo-accounting-company-icon-05.svg" class="h-95px" alt=""></a>
                        </div>
                        <div class="feature-box-content">
                            <a href="demo-accounting-services-details.html"
                                class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Investment
                                consulting</a>
                            <p class="mb-30px">We combine deep financial expertise with exclusive tools to help the
                                maximize value.</p>
                        </div>
                    </div>
                </div> -->
            <!-- end features box item -->
            <!-- start features box item -->
            <!-- <div class="col icon-with-text-style-07 transition-inner-all">
                    <div
                        class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                        <div class="feature-box-icon">
                            <a href="demo-accounting-services-details.html"><img
                                    src="images/demo-accounting-company-icon-06.svg" class="h-95px" alt=""></a>
                        </div>
                        <div class="feature-box-content">
                            <a href="demo-accounting-services-details.html"
                                class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Banking &
                                financing</a>
                            <p class="mb-30px">Financial services are the economic services provided by the finance
                                industry.</p>
                        </div>
                    </div>
                </div> -->
            <!-- end features box item -->
        </div>
    </div>
    </div>
</section>
<!-- end section -->
<!-- <hr> -->

<!-- start section -->
<section class="bg-very-light-gray">
    <div class="container">
        <div class="row justify-content-center mb-3">
            <!-- <div class="row justify-content-center mb-6"> -->
            <div class="col-xl-6 col-md-8 col-sm-10 text-center"
                data-anime='{ "el": "childs", "translateY": [50, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
                <h4 class="mb-0 text-dark-gray fw-700 ls-minus-1px w-85 xl-w-100 mx-auto">Additional
                    Opportunities</h4>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row row-cols-1 row-cols-lg-3 row-cols-md-2 justify-content-center"
            data-anime='{ "el": "childs", "translateY": [50, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
            <!-- start features box item -->
            <div class="col icon-with-text-style-07 transition-inner-all mb-30px">
                <div
                    class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                    <div class="feature-box-icon">
                        <a href="services.html"><img src="images/HUNK/Consulting Services icon.png"
                                style="margin-top: 35px;" class="h-95px" alt=""></a>
                    </div>
                    <div class="feature-box-content">
                        <a href="services.html"
                            class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Consulting
                            Services</a>
                        <p class="mb-30px">We offer consulting services to
                            help businesses optimize their
                            operations, enhance producƟvity, and
                            implement effective strategies for
                            growth.</p>
                    </div>
                </div>
            </div>
            <!-- end features box item -->
            <!-- start features box item -->
            <div class="col icon-with-text-style-07 transition-inner-all mb-30px">
                <div
                    class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                    <div class="feature-box-icon">
                        <a href="demo-accounting-services-details.html"><img
                                src="images/HUNK/project_management icon.jpg" class="h-95px" alt=""></a>
                    </div>
                    <div class="feature-box-content">
                        <a href="services.html"
                            class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Project
                            Management</a>
                        <p class="mb-30px">Our experienced project
                            managers provide comprehensive
                            project management services,
                            ensuring projects are completed on
                            time, within budget, and to the
                            highest quality standards..</p>
                    </div>
                    <!-- <span
                            class="position-absolute box-shadow-large top-25px lg-top-15px right-25px lg-right-15px bg-base-color border-radius-18px text-white fs-11 fw-600 text-uppercase ps-15px pe-15px lh-26 ls-minus-05px">New</span> -->
                </div>
            </div>
            <!-- end features box item -->
            <!-- start features box item -->
            <div class="col icon-with-text-style-07 transition-inner-all mb-30px">
                <div
                    class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                    <div class="feature-box-icon">
                        <a href="demo-accounting-services-details.html"><img
                                src="images/HUNK/training and develope icon.jpg" class="h-95px" alt=""></a>
                    </div>
                    <div class="feature-box-content">
                        <a href="services.html"
                            class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Training and
                            Development</a>
                        <p class="mb-30px">We offer training programs to
                            upskill your workforce in various
                            technical and operational areas,
                            ensuring they are equipped with the
                            latest knowledge and skills.</p>
                    </div>
                </div>
            </div>
            <!-- end features box item -->
            <!-- start features box item -->
            <!-- <div class="col icon-with-text-style-07 transition-inner-all md-mb-30px">
                    <div
                        class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                        <div class="feature-box-icon">
                            <a href="demo-accounting-services-details.html"><img
                                    src="images/demo-accounting-company-icon-04.svg" class="h-95px" alt=""></a>
                        </div>
                        <div class="feature-box-content">
                            <a href="demo-accounting-services-details.html"
                                class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Network Testing Services</a>
                            <p class="mb-30px">Our expert team conducts thorough network tesƟng to ensure the opƟmal performance 
                                and reliability of your IT infrastructure. We specialize in network diagnosƟcs, performance 
                                evaluaƟon, security tesƟng, and maintenance, helping you maintain a robust and secure 
                                network environment.</p>
                        </div>
                    </div>
                </div> -->
            <!-- end features box item -->
            <!-- start features box item -->
            <!-- <div class="col icon-with-text-style-07 transition-inner-all sm-mb-30px">
                    <div
                        class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                        <div class="feature-box-icon">
                            <a href="demo-accounting-services-details.html"><img
                                    src="images/demo-accounting-company-icon-05.svg" class="h-95px" alt=""></a>
                        </div>
                        <div class="feature-box-content">
                            <a href="demo-accounting-services-details.html"
                                class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Investment
                                consulting</a>
                            <p class="mb-30px">We combine deep financial expertise with exclusive tools to help the
                                maximize value.</p>
                        </div>
                    </div>
                </div> -->
            <!-- end features box item -->
            <!-- start features box item -->
            <!-- <div class="col icon-with-text-style-07 transition-inner-all">
                    <div
                        class="bg-white h-100 justify-content-end box-shadow-quadruple-large-hover feature-box flex-column-reverse p-15 md-p-13 border-radius-8px">
                        <div class="feature-box-icon">
                            <a href="demo-accounting-services-details.html"><img
                                    src="images/demo-accounting-company-icon-06.svg" class="h-95px" alt=""></a>
                        </div>
                        <div class="feature-box-content">
                            <a href="demo-accounting-services-details.html"
                                class="d-inline-block fw-600 text-dark-gray mb-5px fs-30 ls-minus-05px">Banking &
                                financing</a>
                            <p class="mb-30px">Financial services are the economic services provided by the finance
                                industry.</p>
                        </div>
                    </div>
                </div> -->
            <!-- end features box item -->
        </div>
    </div>
</section>
<!-- end section -->
<!-- start section -->
<section>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 md-mb-50px"
                data-anime='{ "effect": "slide", "color": "#4daaa7", "direction":"rl", "easing": "easeOutQuad", "delay":50}'>
                <figure class="position-relative m-0 md-w-90">
                    <img src="https://via.placeholder.com/478x544" class="w-90 border-radius-6px" alt="">
                    <figcaption
                        class="position-absolute bg-dark-gray border-radius-8px box-shadow-quadruple-large bottom-100px xs-bottom-minus-20px right-minus-30px w-230px xs-w-210px text-center last-paragraph-no-margin">
                        <div class="bg-white pt-35px pb-35px border-radius-6px mb-10px">
                            <h1 class="fw-700 ls-minus-2px text-dark-gray mb-0">4.8</h1>
                            <div class="text-golden-yellow fs-18 ls-1px mb-5px">
                                <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                                    class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                                    class="fa-solid fa-star"></i>
                            </div>
                            <span class="text-dark-gray d-block fw-600 ls-minus-05px">2488 Reviews</span>
                            <div
                                class="d-inline-block fs-11 text-uppercase bg-green ps-20px pe-20px lh-30 fw-600 text-white border-radius-100px box-shadow-large">
                                Excellent score</div>
                        </div>
                        <!-- <img src="images/demo-real-estate-trustpilot.svg" class="h-30px mb-15px" alt="" /> -->
                    </figcaption>
                </figure>
            </div>
            <div class="col-lg-5 offset-lg-1"
                data-anime='{ "el": "childs", "translateX": [50, 0], "opacity": [0,1], "duration": 1200, "delay": 0, "staggervalue": 150, "easing": "easeOutQuad" }'>
                <div class="mb-20px md-mb-15px">
                    <div class="separator-line-1px w-50px bg-base-color d-inline-block align-middle me-10px opacity-2">
                    </div>
                    <span class="d-inline-block text-dark-gray align-middle fw-500 fs-20">Frequently asked
                        questions</span>
                </div>
                <h3 class="fw-700 text-dark-gray ls-minus-2px sm-ls-minus-1px w-90 lg-w-100">What we can do for your
                    company.</h3>
                <div class="accordion accordion-style-02 w-90 lg-w-100" id="accordion-style-02"
                    data-active-icon="fa-chevron-up" data-inactive-icon="fa-chevron-down">
                    <!-- start accordion item -->
                    <div class="accordion-item">
                        <div class="accordion-header border-bottom border-color-transparent-dark-very-light">
                            <a href="#" data-bs-toggle="collapse" data-bs-target="#accordion-style-02-01"
                                aria-expanded="true" data-bs-parent="#accordion-style-02">
                                <div class="accordion-title mb-0 position-relative text-dark-gray">
                                    <i class="fa-solid fa-chevron-down fs-15"></i><span
                                        class="fs-19 fw-600 ls-minus-05px">What is tax and legal advisory?</span>
                                </div>
                            </a>
                        </div>
                        <div id="accordion-style-02-01" class="accordion-collapse collapse"
                            data-bs-parent="#accordion-style-02">
                            <div
                                class="accordion-body last-paragraph-no-margin border-bottom border-color-transparent-dark-very-light">
                                <p>The focus of the tax and legal department is on advisory services in the tax law.
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- end accordion item -->
                    <!-- start accordion item -->
                    <div class="accordion-item active-accordion">
                        <div class="accordion-header border-bottom border-color-transparent-dark-very-light">
                            <a href="#" data-bs-toggle="collapse" data-bs-target="#accordion-style-02-02"
                                aria-expanded="false" data-bs-parent="#accordion-style-02">
                                <div class="accordion-title mb-0 position-relative text-dark-gray">
                                    <i class="fa-solid fa-chevron-up fs-15"></i><span
                                        class="fs-19 fw-600 ls-minus-05px">What is company accounting?</span>
                                </div>
                            </a>
                        </div>
                        <div id="accordion-style-02-02" class="accordion-collapse collapse show"
                            data-bs-parent="#accordion-style-02">
                            <div
                                class="accordion-body last-paragraph-no-margin border-bottom border-color-transparent-dark-very-light">
                                <p>The focus of the tax and legal department is on advisory services in the tax law.
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- end accordion item -->
                    <!-- start accordion item -->
                    <div class="accordion-item">
                        <div class="accordion-header border-bottom border-color-transparent">
                            <a href="#" data-bs-toggle="collapse" data-bs-target="#accordion-style-02-03"
                                aria-expanded="false" data-bs-parent="#accordion-style-02">
                                <div class="accordion-title mb-0 position-relative text-dark-gray">
                                    <i class="fa-solid fa-chevron-down fs-15"></i><span
                                        class="fs-19 fw-600 ls-minus-05px">What do you do for corporate
                                        clients?</span>
                                </div>
                            </a>
                        </div>
                        <div id="accordion-style-02-03" class="accordion-collapse collapse"
                            data-bs-parent="#accordion-style-02">
                            <div class="accordion-body last-paragraph-no-margin border-bottom border-color-transparent">
                                <p>The focus of the tax and legal department is on advisory services in the tax law.
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- end accordion item -->
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-6 sm-mt-4">
            <!-- start features box item -->
            <div class="col-auto icon-with-text-style-08 md-mb-15px"
                data-anime='{ "translateX": [-50, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <div class="feature-box feature-box-left-icon-middle">
                    <div class="feature-box-icon me-10px">
                        <i class="bi bi-chat-square-text icon-extra-medium text-dark-gray"></i>
                    </div>
                    <div class="feature-box-content">
                        <span class="alt-font text-dark-gray fw-500 fs-19">Looking for help? <a href="contact.html"
                                class="text-decoration-line-bottom text-dark-gray fw-600">Contact today</a></span>
                    </div>
                </div>
            </div>
            <!-- end features box item -->
            <!-- start features box item -->
            <div class="col-auto icon-with-text-style-08"
                data-anime='{ "translateX": [50, 0], "opacity": [0,1], "duration": 600, "delay": 0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <div class="feature-box feature-box-left-icon-middle">
                    <!-- <div class="feature-box-icon me-10px">
                            <i class="bi bi-briefcase icon-extra-medium text-dark-gray"></i>
                        </div> -->
                    <!-- <div class="feature-box-content">
                            <span class="alt-font text-dark-gray fw-500 fs-19">Free Consultation? <a
                                    href="demo-accounting-services.html"
                                    class="text-decoration-line-bottom text-dark-gray fw-600">Accounting
                                    services</a></span>
                        </div> -->
                </div>
            </div>
            <!-- end features box item -->
        </div>
    </div>
</section>
<!-- end section -->
<?php include ('footer.php') ?>